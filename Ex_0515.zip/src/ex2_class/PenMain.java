package ex2_class;

public class PenMain {
	public static void main(String[] args) {
		
		Pen p1 = new Pen();
		Pen p2 = new Pen();
		
		p1.info();
		p2.info();
		
		Pen gold = new Pen();
		gold.color = "gold";
		gold.com = "���";
		gold.info();
		
		
	}//main
}



















































