package ex3_method;

public class ValueMain {
	public static void main(String[] args) {
		
		int su = 200;
		
		ValueTest vt = new ValueTest();
		vt.test(su);
		
		System.out.println( "su : " + su );
		
		System.out.println("---------------------");
		
		vt.sum(10, 15);
		
	}//main
}












































