package ex3_method;

public class ValueTest {

	public void test( int num ) {
		
		num += 10;
		System.out.println("test() �޼��� ȣ�� : " + num);
		
	}//test()
	
	public void sum( int n1, int n2 ) {
		
		System.out.println( n1 + n2 ); 
		
	}
	
}






































