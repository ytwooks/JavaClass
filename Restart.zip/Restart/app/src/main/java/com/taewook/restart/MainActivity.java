package com.taewook.restart;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //1. 처리할 버튼을 찾아라
        Button restartButton = findViewById(R.id.restartButton);

        //2. 버튼을 클릭했을 때, 처리할 것을 셋팅
        restartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "너 날                 눌렀구나 ㅠ", Toast.LENGTH_SHORT).show();
                //3. 처리할 내용은 DietActivity를 시작

                Intent goDiet = new Intent(getApplicationContext(), DietActivity.class);
                startActivity(goDiet);

            }
        });



    }
}
