package com.taewook.restart;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class ThirdActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        Button thirdButton = findViewById(R.id.thirdButton);

        thirdButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "맨 앞으로  앞으로 앞으로 앞으로 앞으로", Toast.LENGTH_SHORT).show();
                Intent goFirst = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(goFirst);
            }
        });

    }
}
