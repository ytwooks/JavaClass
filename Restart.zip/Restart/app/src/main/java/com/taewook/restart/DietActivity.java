package com.taewook.restart;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class DietActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diet);

        //1. 처리할 버튼을 찾아라
        Button restartButton = findViewById(R.id.goStart);

        //2. 버튼을 클릭했을 때, 처리할 것을 셋팅
        restartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "처음으로 돌아갑니당", Toast.LENGTH_SHORT).show();
//                3. 처리할 내용은 DietActivity를 시작
//                2-1 액티비티를 넘길때는
//                - 액티비티를 넘길 수 있는 부품을 셋팅
//                - intent복사해서 가지고 온 다음
                Intent goThird = new Intent(getApplicationContext(), ThirdActivity.class);
//                현재액티비티  ---> 가야할 액티비티 셋팅
//                2-2  intent부품 시작
                startActivity(goThird);

            }
        });


    }
}
