import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import javax.swing.SwingConstants;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.awt.event.ActionEvent;

public class MyDiary extends JFrame {
	private JTextField textField;
	private JTextField noText;
	private JTextField titleText;

	public MyDiary() {
		getContentPane().setFont(new Font("굴림", Font.BOLD, 20));
		getContentPane().setBackground(Color.GREEN);

		setTitle("나의 일기장");
		setSize(300, 500);
		getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

		JLabel noLabel = new JLabel("번호");
		noLabel.setHorizontalAlignment(SwingConstants.CENTER);
		getContentPane().add(noLabel);

		noText = new JTextField();
		getContentPane().add(noText);
		noText.setColumns(24);

		JLabel lblNewLabel = new JLabel("제목");
		getContentPane().add(lblNewLabel);

		titleText = new JTextField();
		getContentPane().add(titleText);
		titleText.setColumns(24);

		JLabel lblNewLabel_1 = new JLabel("내용");
		getContentPane().add(lblNewLabel_1);

		JTextArea contentText = new JTextArea();
		contentText.setRows(10);
		contentText.setColumns(35);
		getContentPane().add(contentText);


		JButton save = new JButton("일기저장");
		save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String noT = noText.getText();
				String titleT = titleText.getText();
				String contentT = contentText.getText();

				try {
					FileWriter f = new FileWriter("c:/diary/" + noT + ".txt");
					f.write(noT + "\r");
					f.write(titleT + "\r");
					f.write(contentT + "\r");
					f.flush();
					f.close();

					noText.setText("");
					titleText.setText("");
					contentText.setText("");

					JOptionPane.showMessageDialog(null, "잘했어요");

				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null, "못했어요");
				}
			}
		});
		save.setFont(new Font("굴림", Font.BOLD, 30));
		getContentPane().add(save);
		
		JButton read = new JButton("일기읽기");
		read.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String noT = noText.getText();
				
				try {
					FileReader f2 = new FileReader("c:/diary/" + noT + ".txt");
					BufferedReader reader = new BufferedReader(f2);
					String noR = reader.readLine();
					String titleR = reader.readLine();
					String contentR = reader.readLine();

					noText.setText(noR);
					titleText.setText(titleR);
					contentText.setText(contentR);
					
					noText.setForeground(Color.RED);
					
					JOptionPane.showMessageDialog(null, "읽기 잘했어요");
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "읽기 못했어요");
				}
			}
		});
		
		read.setFont(new Font("굴림", Font.BOLD, 30));
		getContentPane().add(read);
		
		JButton reset = new JButton("초기화");
		reset.setFont(new Font("굴림", Font.BOLD, 40));
		reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				noText.setText("");
				titleText.setText("");
				contentText.setText("");
			}
		});
		getContentPane().add(reset);

		setVisible(true);

	}

	public static void main(String[] args) {
		MyDiary name = new MyDiary();
	}

}
