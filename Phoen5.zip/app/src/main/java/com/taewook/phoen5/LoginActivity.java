package com.taewook.phoen5;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);



        Button login = findViewById(R.id.button1);

        login.setOnClickListener(new View.OnClickListener() {

            String id1 = "ytwooks";
            String pw1 = "1234";

            @Override
            public void onClick(View v) {

                EditText id2 = findViewById(R.id.id2);
                EditText pw2 = findViewById(R.id.pw);

                String id = id2.getText().toString();
                String pw = pw2.getText().toString();

                if(id.equals(id1) && pw.equals(pw1)) {
                    Intent intent = new Intent(getApplicationContext(), OkActivity.class);
                    startActivity(intent);
                } else {
                    Intent intent = new Intent(getApplicationContext(), NotActivity.class);
                    startActivity(intent);
                }
            }
        });



    }
}
