package com.taewook.phoen5;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cal);


        //1. 배치에 있던 button을 찾아서.
        Button plus = findViewById(R.id.plus);

        //2. button을 눌렀을 때, 액션처리 셋팅
        //3. 액션처리 구체적인 내용
        //    Cal액티비티로 넘김.

        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText num1 = findViewById(R.id.num1);
                EditText num2 = findViewById(R.id.num2);

                String n1 = num1.getText().toString();
                String n2 = num2.getText().toString();
                int i1 = Integer.parseInt(n1);
                int i2 = Integer.parseInt(n2);

                int total = i1 + i2;
                Toast.makeText(getApplicationContext(), "두 수의 합은 : " + total, Toast.LENGTH_LONG).show();
                TextView result = findViewById(R.id.result);
                result.setText("두 수의 합은: " + total);
            }
        });

        //1. 배치에 있던 button을 찾아서.
        Button minus = findViewById(R.id.minus);

        //2. button을 눌렀을 때, 액션처리 셋팅
        //3. 액션처리 구체적인 내용
        //    Cal액티비티로 넘김.

        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText num1 = findViewById(R.id.num1);
                EditText num2 = findViewById(R.id.num2);

                String n1 = num1.getText().toString();
                String n2 = num2.getText().toString();
                int i1 = Integer.parseInt(n1);
                int i2 = Integer.parseInt(n2);

                int total = i1 - i2;
                Toast.makeText(getApplicationContext(), "두 수의 차는 : " + total, Toast.LENGTH_LONG).show();
                TextView result = findViewById(R.id.result);
                result.setText("두 수의 차는: " + total);
            }
        });

//1. 배치에 있던 button을 찾아서.
        Button main = findViewById(R.id.main);

        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }
    }