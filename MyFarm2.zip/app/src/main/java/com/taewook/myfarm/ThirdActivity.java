package com.taewook.myfarm;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ThirdActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        setTitle("셋째");

        Button third = findViewById(R.id.post5);
        third.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView third = findViewById(R.id.diary5);
                CharSequence thirdSaid = " 셋째: " + third.getText() + "\n";
                TextView allDiary = findViewById(R.id.allDiary5);
                allDiary.append(thirdSaid);
                third.setText("");
            }
        });

        Button main = findViewById(R.id.toMain5);
        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

    }
}
