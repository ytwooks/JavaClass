package com.taewook.myfarm;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MotherActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mother);
        setTitle("어무이");

        Button mother = findViewById(R.id.post2);
        mother.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView mother = findViewById(R.id.diary2);
                CharSequence motherSaid = " 엄마: " + mother.getText() + "\n";
                TextView allDiary = findViewById(R.id.allDiary2);
                allDiary.append(motherSaid);
                mother.setText("");
            }
        });

        Button main = findViewById(R.id.toMain3);
        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });


    }
}
