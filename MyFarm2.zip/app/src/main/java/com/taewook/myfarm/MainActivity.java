package com.taewook.myfarm;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static ArrayList<String> list = new ArrayList<>();

//    public static  ArrayList<String> getList(String) {
//        list.add(String)
//
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("My Farm");
        //list.set(0,"안녕");

        //**************아빠 버튼 제작*************
        Button father = findViewById(R.id.fatherButton);
        father.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText id0 = findViewById(R.id.idText);
                EditText pw0 = findViewById(R.id.pwText);

                String id = id0.getText().toString();
                String pw = pw0.getText().toString();

                if (id.equals("father") && pw.equals("1234")) {
                    Intent intent = new Intent(getApplicationContext(), FatherActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), "사용자 정보가 잘못 되었습니다.", Toast.LENGTH_LONG).show();
                }
            }
        });

        //**************엄마 버튼 제작*************
        Button mother = findViewById(R.id.motherButton);
        mother.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText id1 = findViewById(R.id.idText);
                EditText pw1 = findViewById(R.id.pwText);

                String id = id1.getText().toString();
                String pw = pw1.getText().toString();

                if (id.equals("mother") && pw.equals("5678")) {
                    Intent intent = new Intent(getApplicationContext(), MotherActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), "사용자 정보가 잘못 되었습니다.", Toast.LENGTH_LONG).show();
                }
            }
        });

        //**************첫째 버튼 제작*************
        Button first = findViewById(R.id.firstButton);
        first.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText idInput = findViewById(R.id.idText);
                EditText pwInput = findViewById(R.id.pwText);

                String id = idInput.getText().toString();
                String pw = pwInput.getText().toString();

                if (id.equals("first") && pw.equals("9012")) {
                    Intent intent = new Intent(getApplicationContext(), FirstActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), "사용자 정보가 잘못 되었습니다.", Toast.LENGTH_LONG).show();
                }
            }
        });

        //**************둘째 버튼 제작*************
        Button second = findViewById(R.id.secondButton);
        second.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText idInput = findViewById(R.id.idText);
                EditText pwInput = findViewById(R.id.pwText);

                String id = idInput.getText().toString();
                String pw = pwInput.getText().toString();

                if (id.equals("second") && pw.equals("3456")) {
                    Intent intent = new Intent(getApplicationContext(), SecondActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), "사용자 정보가 잘못 되었습니다.", Toast.LENGTH_LONG).show();
                }
            }
        });

        //**************셋째 버튼 제작*************
        Button third = findViewById(R.id.thirdButton);
        third.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText idInput = findViewById(R.id.idText);
                EditText pwInput = findViewById(R.id.pwText);

                String id = idInput.getText().toString();
                String pw = pwInput.getText().toString();

                if (id.equals("third") && pw.equals("3456")) {
                    Intent intent = new Intent(getApplicationContext(), ThirdActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), "사용자 정보가 잘못 되었습니다.", Toast.LENGTH_LONG).show();
                }
            }
        });

    }
}
