package com.taewook.myfarm;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class FirstActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
        setTitle("딸래미");

        Button first = findViewById(R.id.post3);
        first.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView first = findViewById(R.id.diary1);
                String firstSaid = " 첫째: " + first.getText() + "\n";
                TextView allDiary = findViewById(R.id.allDiary3);
                allDiary.append(firstSaid);
                first.setText("");
            }
        });

        Button main = findViewById(R.id.toMain2);
        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

    }
}
