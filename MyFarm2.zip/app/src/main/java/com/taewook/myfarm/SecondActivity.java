package com.taewook.myfarm;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        setTitle("둘째");

        Button second = findViewById(R.id.post4);
        second.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView second = findViewById(R.id.diary4);
                CharSequence secondSaid = " 둘째: " + second.getText() + "\n";
                TextView allDiary = findViewById(R.id.allDiary4);
                allDiary.append(secondSaid);
                second.setText("");
            }
        });

        Button main = findViewById(R.id.toMain4);
        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

    }
}
