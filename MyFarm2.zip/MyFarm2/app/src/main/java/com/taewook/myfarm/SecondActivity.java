package com.taewook.myfarm;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    public static Context mContext;
    public static String secondSay = new String();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        setTitle("둘째");

        mContext = this;

        final String[] common = ((MainActivity)MainActivity.mContext).allComment;
        TextView allDiary = findViewById(R.id.allDiary4);
        allDiary.setText(((MainActivity)MainActivity.mContext).allComment[0] + "\n" +
                ((MainActivity)MainActivity.mContext).allComment[1] + "\n" +
                ((MainActivity)MainActivity.mContext).allComment[2] + "\n" +
                ((MainActivity)MainActivity.mContext).allComment[4] + "\n");

        Button second = findViewById(R.id.post4);
        second.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView second = findViewById(R.id.diary4);
                String secondSaid = " 둘째: " + second.getText() + "\n";
                TextView allDiary = findViewById(R.id.allDiary4);
                allDiary.setText(secondSaid);
                secondSay = allDiary.getText() + "";
                second.setText("");
            }
        });

        Button main = findViewById(R.id.toMain4);
        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                setResult(4, intent);
                finish();
            }
        });

    }
}
