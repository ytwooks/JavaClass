package com.taewook.myfarm;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static Context mContext;


    public static String[] allComment = {"", "" , "", "", ""};


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        TextView a = findViewById(R.id.idText);
        TextView b = findViewById(R.id.pwText);
        b.setText("");
        a.setText("");

        if (resultCode == 1) {
            allComment[0] = ((FatherActivity)FatherActivity.mContext).fatherSay;
        }
        if (resultCode == 2) {
            allComment[1] = ((MotherActivity)MotherActivity.mContext).motherSay;
        }
        if (resultCode == 3) {
            allComment[2] = ((FirstActivity)FirstActivity.mContext).firstSay;
        }
        if (resultCode == 4) {
            allComment[3] = ((SecondActivity)SecondActivity.mContext).secondSay;
        }
        if (resultCode == 5) {
            allComment[4] = ((ThirdActivity)ThirdActivity.mContext).thirdSay;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("My Farm");

        mContext = this;

        //**************아빠 버튼 제작*************
        Button father = findViewById(R.id.fatherButton);
        father.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText id0 = findViewById(R.id.idText);
                EditText pw0 = findViewById(R.id.pwText);

                String id = id0.getText().toString();
                String pw = pw0.getText().toString();

                if (id.equals("father") && pw.equals("1234")) {
                    Intent intent = new Intent(getApplicationContext(), FatherActivity.class);
                    startActivityForResult(intent,1);
                } else {
                    Toast.makeText(getApplicationContext(), "사용자 정보가 잘못 되었습니다.", Toast.LENGTH_LONG).show();
                }
            }
        });

        //**************엄마 버튼 제작*************
        Button mother = findViewById(R.id.motherButton);
        mother.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText id1 = findViewById(R.id.idText);
                EditText pw1 = findViewById(R.id.pwText);

                String id = id1.getText().toString();
                String pw = pw1.getText().toString();

                if (id.equals("mother") && pw.equals("5678")) {
                    Intent intent = new Intent(getApplicationContext(), MotherActivity.class);
                    startActivityForResult(intent,2);
                } else {
                    Toast.makeText(getApplicationContext(), "사용자 정보가 잘못 되었습니다.", Toast.LENGTH_LONG).show();
                }
            }
        });

        //**************첫째 버튼 제작*************
        Button first = findViewById(R.id.firstButton);
        first.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText idInput = findViewById(R.id.idText);
                EditText pwInput = findViewById(R.id.pwText);

                String id = idInput.getText().toString();
                String pw = pwInput.getText().toString();

                if (id.equals("first") && pw.equals("9012")) {
                    Intent intent = new Intent(getApplicationContext(), FirstActivity.class);
                    startActivityForResult(intent,3);
                } else {
                    Toast.makeText(getApplicationContext(), "사용자 정보가 잘못 되었습니다.", Toast.LENGTH_LONG).show();
                }
            }
        });

        //**************둘째 버튼 제작*************
        Button second = findViewById(R.id.secondButton);
        second.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText idInput = findViewById(R.id.idText);
                EditText pwInput = findViewById(R.id.pwText);

                String id = idInput.getText().toString();
                String pw = pwInput.getText().toString();

                if (id.equals("second") && pw.equals("3456")) {
                    Intent intent = new Intent(getApplicationContext(), SecondActivity.class);
                    startActivityForResult(intent,4);
                } else {
                    Toast.makeText(getApplicationContext(), "사용자 정보가 잘못 되었습니다.", Toast.LENGTH_LONG).show();
                }
            }
        });

        //**************셋째 버튼 제작*************
        Button third = findViewById(R.id.thirdButton);
        third.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText idInput = findViewById(R.id.idText);
                EditText pwInput = findViewById(R.id.pwText);

                String id = idInput.getText().toString();
                String pw = pwInput.getText().toString();

                if (id.equals("third") && pw.equals("3456")) {
                    Intent intent = new Intent(getApplicationContext(), ThirdActivity.class);
                    startActivityForResult(intent,5);
                } else {
                    Toast.makeText(getApplicationContext(), "사용자 정보가 잘못 되었습니다.", Toast.LENGTH_LONG).show();
                }
            }
        });





    }
}
