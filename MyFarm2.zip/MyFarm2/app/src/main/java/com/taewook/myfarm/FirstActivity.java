package com.taewook.myfarm;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class FirstActivity extends AppCompatActivity {

    public static Context mContext;
    public static String firstSay = new String();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
        setTitle("딸래미");

        mContext = this;

        final String[] common = ((MainActivity)MainActivity.mContext).allComment;
        TextView allDiary = findViewById(R.id.allDiary3);
        allDiary.setText(((MainActivity)MainActivity.mContext).allComment[0] + "\n" +
                ((MainActivity)MainActivity.mContext).allComment[1] + "\n" +
                ((MainActivity)MainActivity.mContext).allComment[3] + "\n" +
                ((MainActivity)MainActivity.mContext).allComment[4] + "\n");

        Button first = findViewById(R.id.post3);
        first.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView first = findViewById(R.id.diary3);
                String firstSaid = " 첫째: " + first.getText() + "\n";
                TextView allDiary = findViewById(R.id.allDiary3);
                allDiary.setText(firstSaid);
                firstSay = allDiary.getText() + "";
                first.setText("");
            }
        });

        Button main = findViewById(R.id.toMain3);
        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                setResult(3, intent);
                finish();
            }
        });

    }
}
