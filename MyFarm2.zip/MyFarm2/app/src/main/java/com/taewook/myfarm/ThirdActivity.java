package com.taewook.myfarm;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ThirdActivity extends AppCompatActivity {

    public static Context mContext;
    public static String thirdSay = new String();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        setTitle("셋째");

        mContext = this;

        final String[] common = ((MainActivity)MainActivity.mContext).allComment;
        TextView allDiary = findViewById(R.id.allDiary5);
        allDiary.setText(((MainActivity)MainActivity.mContext).allComment[0] + "\n" +
                ((MainActivity)MainActivity.mContext).allComment[1] + "\n" +
                ((MainActivity)MainActivity.mContext).allComment[2] + "\n" +
                ((MainActivity)MainActivity.mContext).allComment[3] + "\n");

        Button third = findViewById(R.id.post5);
        third.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView third = findViewById(R.id.diary5);
                String thirdSaid = " 셋째: " + third.getText() + "\n";
                TextView allDiary = findViewById(R.id.allDiary5);
                allDiary.setText(thirdSaid);
                thirdSay = allDiary.getText() + "";
                third.setText("");
            }
        });

        Button main = findViewById(R.id.toMain5);
        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                setResult(5, intent);
                finish();
            }
        });

    }
}
