package com.taewook.myfarm;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class FatherActivity extends AppCompatActivity {

    public static Context mContext;
    public static String fatherSay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_father);
        setTitle("아부지");

        mContext = this;

        //final String[] common = ((MainActivity)MainActivity.mContext).allComment;

        final TextView allDiary = findViewById(R.id.allDiary1);
        allDiary.setText(((MainActivity)MainActivity.mContext).allComment[1] + "\n" +
                ((MainActivity)MainActivity.mContext).allComment[2] + "\n" +
                ((MainActivity)MainActivity.mContext).allComment[3] + "\n" +
                ((MainActivity)MainActivity.mContext).allComment[4] + "\n");


        Button father = findViewById(R.id.post1);
        father.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView father = findViewById(R.id.diary1);
                String fatherSaid = "아빠: " + father.getText() + "\n";
                TextView allDiary = findViewById(R.id.allDiary1);
                allDiary.setText(fatherSaid);
                fatherSay = allDiary.getText() + "";
                father.setText("");
                //main.list.set(0,fatherSaid);

            }
        });

        Button main = findViewById(R.id.toMain1);
        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                setResult(1, intent);
                finish();

            }
        });

    }
}
