package com.taewook.myfarm;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MotherActivity extends AppCompatActivity {

    public static Context mContext;
    public static String motherSay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mother);
        setTitle("어무이");

        mContext = this;

        final String[] common = ((MainActivity)MainActivity.mContext).allComment;
        TextView allDiary = findViewById(R.id.allDiary2);
        allDiary.setText(((MainActivity)MainActivity.mContext).allComment[0] + "\n" +
                ((MainActivity)MainActivity.mContext).allComment[2] + "\n" +
                ((MainActivity)MainActivity.mContext).allComment[3] + "\n" +
                ((MainActivity)MainActivity.mContext).allComment[4] + "\n");

        Button mother = findViewById(R.id.post2);
        mother.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView mother = findViewById(R.id.diary2);
                String motherSaid = " 엄마: " + mother.getText() + "\n";
                TextView allDiary = findViewById(R.id.allDiary2);
                allDiary.setText(motherSaid);
                motherSay = allDiary.getText() + "";
                mother.setText("");
            }
        });

        Button main = findViewById(R.id.toMain2);
        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                setResult(2, intent);
                finish();
            }
        });


    }
}
